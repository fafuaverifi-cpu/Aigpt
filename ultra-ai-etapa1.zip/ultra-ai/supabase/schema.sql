-- ULTRA AI · Etapa 1. Ejecuta este archivo en Supabase -> SQL Editor.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  plan text not null default 'free' check (plan in ('free','pro','ultra')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Nueva conversación',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conversations_user_updated on public.conversations(user_id, updated_at desc);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  input_tokens int,
  output_tokens int,
  created_at timestamptz not null default now()
);
create index if not exists messages_conv_created on public.messages(conversation_id, created_at);
create index if not exists messages_user_created on public.messages(user_id, created_at);

-- Perfil automático al registrarse
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Seguridad por filas: cada usuario solo ve y modifica lo suyo
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

create policy "perfil: leer el propio" on public.profiles
  for select using (id = auth.uid());
create policy "perfil: editar el propio" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());
-- El usuario NO puede cambiar su plan: solo el nombre
revoke update on public.profiles from authenticated, anon;
grant update (display_name) on public.profiles to authenticated;

create policy "chats: leer los propios" on public.conversations
  for select using (user_id = auth.uid());
create policy "chats: crear los propios" on public.conversations
  for insert with check (user_id = auth.uid());
create policy "chats: editar los propios" on public.conversations
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "chats: borrar los propios" on public.conversations
  for delete using (user_id = auth.uid());

create policy "mensajes: leer los propios" on public.messages
  for select using (user_id = auth.uid());
create policy "mensajes: crear en chats propios" on public.messages
  for insert with check (
    user_id = auth.uid()
    and exists (select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid())
  );
create policy "mensajes: borrar los propios" on public.messages
  for delete using (user_id = auth.uid());

# ULTRA AI · Etapa 1

Chat con IA con cuentas, historial guardado, modo claro/oscuro y español/inglés.

**Incluye:** registro, login, recuperación de contraseña, verificación de correo, Google (opcional), chat con streaming, historial (buscar, renombrar, eliminar), límite diario del plan Gratis, eliminación de cuenta.
**Todavía no incluye (Etapas 2–4):** pagos con Stripe, planes Pro/Ultra, archivos, imágenes, búsqueda web, voz, panel de administración, varios modelos.

## Qué cuentas necesitas

| Servicio | Para qué | Costo |
|---|---|---|
| Supabase | Base de datos y cuentas | Capa gratuita |
| Anthropic (console.anthropic.com) | Respuestas de la IA | De pago por uso (requiere crédito) |
| Vercel | Poner la app en línea | Capa gratuita |
| GitHub | Subir el código para Vercel | Gratis |

## 1. Supabase
1. Crea un proyecto en supabase.com.
2. SQL Editor → pega todo `supabase/schema.sql` → Run.
3. Project Settings → API: copia **Project URL**, **anon public key** y **service_role key**.
4. Authentication → URL Configuration: pon tu dirección (`http://localhost:3000` para probar; luego la de Vercel) en *Site URL* y añade `/**` a *Redirect URLs* (ej. `https://tu-app.vercel.app/**`).
5. (Opcional) Authentication → Providers → Google, y pon `NEXT_PUBLIC_GOOGLE_AUTH=true`.

## 2. Ejecutar en tu computadora
```bash
npm install
cp .env.example .env.local   # rellena las claves
npm run dev
```
Abre http://localhost:3000, crea una cuenta y escribe un mensaje.

## 3. Poner la app en línea (Vercel)
1. Sube la carpeta a un repositorio de GitHub (`.env.local` no se sube, ya está en `.gitignore`).
2. En vercel.com → Add New → Project → elige el repositorio.
3. En *Environment Variables* añade todas las del `.env.example`.
4. Deploy. Actualiza *Site URL* y *Redirect URLs* en Supabase con la dirección que te dé Vercel.

## 4. Usarla desde Android
La app es web: abre la dirección de Vercel en Chrome. Menú ⋮ → **Añadir a pantalla de inicio** para tener un acceso directo.
No hace falta instalar Node en el teléfono; desarrolla en un ordenador o con GitHub Codespaces desde el navegador.

## Avisos claros
- Sin `ANTHROPIC_API_KEY` el chat muestra un aviso y no responde.
- Sin `SUPABASE_SERVICE_ROLE_KEY` no funciona "Eliminar mi cuenta" (el resto sí).
- Las claves solo viven en variables de entorno del servidor; solo las que empiezan por `NEXT_PUBLIC_` llegan al navegador y son públicas por diseño (la clave `anon` está protegida por las reglas de seguridad por filas del SQL).
- El plan de cada usuario solo se puede cambiar desde el servidor; un usuario no puede editarlo.

## Estructura
```
src/app/            páginas (login, register, chat…) y API (/api/chat, /api/account)
src/components/     AuthForm, ChatApp
src/lib/            clientes de Supabase, textos es/en
supabase/schema.sql tablas y seguridad por filas
```

"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient, supabaseConfigured } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";

export function Wordmark() {
  return (
    <div className="text-5xl font-extrabold tracking-tight leading-none">
      ULTRA<span className="text-accent">.</span>AI
    </div>
  );
}

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const { t } = useI18n();
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const isLogin = mode === "login";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");
    if (!isLogin && password.length < 8) {
      setError(t("password"));
      return;
    }
    setBusy(true);
    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.replace("/chat");
        router.refresh();
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { display_name: name || email.split("@")[0] },
            emailRedirectTo: `${location.origin}/auth/callback`,
          },
        });
        if (error) throw error;
        if (data.session) {
          router.replace("/chat");
          router.refresh();
        } else {
          setInfo(t("checkEmail"));
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t("genericError"));
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${location.origin}/auth/callback` },
    });
  }

  const field =
    "w-full rounded-lg border border-line bg-surface px-3 py-2.5 text-base outline-none focus:border-accent";

  return (
    <main className="min-h-screen grid place-items-center px-5 py-10">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="mt-8 mb-5 text-xl font-semibold">{isLogin ? t("login") : t("register")}</h1>
        {!supabaseConfigured && (
          <p role="alert" className="mb-4 rounded-lg border border-line bg-surface p-3 text-sm">
            {t("configMissing")}
          </p>
        )}
        <form onSubmit={submit} className="space-y-3">
          {!isLogin && (
            <input className={field} placeholder={t("name")} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
          )}
          <input className={field} type="email" required placeholder={t("email")} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          <input className={field} type="password" required minLength={isLogin ? 1 : 8} placeholder={t("password")} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={isLogin ? "current-password" : "new-password"} />
          {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{error}</p>}
          {info && <p role="status" className="text-sm">{info}</p>}
          <button disabled={busy || !supabaseConfigured} className="w-full rounded-lg bg-accent text-on-accent font-semibold py-2.5 disabled:opacity-50">
            {isLogin ? t("login") : t("register")}
          </button>
        </form>
        {process.env.NEXT_PUBLIC_GOOGLE_AUTH === "true" && (
          <button onClick={google} className="mt-3 w-full rounded-lg border border-line bg-surface py-2.5 font-medium">
            {t("google")}
          </button>
        )}
        <div className="mt-6 space-y-2 text-sm text-mute">
          {isLogin && (
            <p><Link className="underline" href="/forgot-password">{t("forgot")}</Link></p>
          )}
          <p>
            {isLogin ? t("noAccount") : t("haveAccount")}{" "}
            <Link className="underline text-ink" href={isLogin ? "/register" : "/login"}>
              {isLogin ? t("register") : t("login")}
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}

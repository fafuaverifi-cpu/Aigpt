"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import ReactMarkdown from "react-markdown";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";

type Conv = { id: string; title: string; updated_at: string };
type Msg = { id?: string; role: "user" | "assistant"; content: string };

export default function ChatApp({ email }: { email: string }) {
  const supabase = useMemo(() => createClient(), []);
  const router = useRouter();
  const { t, lang, setLang } = useI18n();

  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [drawer, setDrawer] = useState(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const loadConvs = useCallback(async () => {
    const { data } = await supabase
      .from("conversations")
      .select("id,title,updated_at")
      .order("updated_at", { ascending: false });
    setConvs(data ?? []);
  }, [supabase]);

  useEffect(() => {
    loadConvs();
  }, [loadConvs]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages]);

  async function openConv(id: string) {
    setActiveId(id);
    setError("");
    setDrawer(false);
    const { data } = await supabase
      .from("messages")
      .select("id,role,content")
      .eq("conversation_id", id)
      .order("created_at", { ascending: true });
    setMessages((data ?? []) as Msg[]);
  }

  function newChat() {
    setActiveId(null);
    setMessages([]);
    setError("");
    setDrawer(false);
  }

  async function send(e?: React.FormEvent) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || streaming) return;
    setInput("");
    setError("");
    setStreaming(true);
    setMessages((m) => [...m, { role: "user", content: text }, { role: "assistant", content: "" }]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: activeId, message: text }),
      });
      if (!res.ok || !res.body) {
        const body = await res.json().catch(() => null);
        throw new Error(body?.error ?? t("genericError"));
      }
      const id = res.headers.get("X-Conversation-Id");
      if (id && !activeId) setActiveId(id);

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        setMessages((m) => {
          const copy = [...m];
          const last = copy[copy.length - 1];
          copy[copy.length - 1] = { ...last, content: last.content + chunk };
          return copy;
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t("genericError"));
      setMessages((m) => (m[m.length - 1]?.content === "" ? m.slice(0, -1) : m));
    } finally {
      setStreaming(false);
      loadConvs();
    }
  }

  async function saveRename(id: string) {
    const title = renameValue.trim();
    setRenaming(null);
    if (!title) return;
    await supabase.from("conversations").update({ title }).eq("id", id);
    loadConvs();
  }

  async function removeConv(id: string) {
    if (!confirm(t("delConfirm"))) return;
    await supabase.from("conversations").delete().eq("id", id);
    if (id === activeId) newChat();
    loadConvs();
  }

  async function copy(text: string, i: number) {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIdx(i);
      setTimeout(() => setCopiedIdx(null), 1500);
    } catch {
      /* el navegador bloqueó el portapapeles */
    }
  }

  function toggleTheme() {
    const dark = document.documentElement.classList.toggle("dark");
    localStorage.setItem("theme", dark ? "dark" : "light");
  }

  async function logout() {
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  }

  async function deleteAccount() {
    if (!confirm(t("deleteAccountConfirm"))) return;
    const res = await fetch("/api/account", { method: "DELETE" });
    if (res.ok) {
      router.replace("/login");
      router.refresh();
    } else {
      const body = await res.json().catch(() => null);
      setError(body?.error ?? t("genericError"));
    }
  }

  const filtered = convs.filter((c) => c.title.toLowerCase().includes(query.trim().toLowerCase()));
  const small = "rounded-md px-2 py-1 text-sm hover:bg-line/60";

  const sidebar = (
    <aside className="flex h-full w-72 flex-col border-r border-line bg-surface">
      <div className="p-3 space-y-2">
        <div className="px-1 text-xl font-extrabold tracking-tight">
          ULTRA<span className="text-accent">.</span>AI
        </div>
        <button onClick={newChat} className="w-full rounded-lg bg-accent px-3 py-2 font-semibold text-on-accent">
          + {t("newChat")}
        </button>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("search")}
          aria-label={t("search")}
          className="w-full rounded-lg border border-line bg-paper px-3 py-2 text-base outline-none focus:border-accent"
        />
      </div>
      <nav className="flex-1 overflow-y-auto px-2 pb-2">
        {convs.length === 0 && <p className="px-2 py-3 text-sm text-mute">{t("noChats")}</p>}
        {convs.length > 0 && filtered.length === 0 && <p className="px-2 py-3 text-sm text-mute">{t("noResults")}</p>}
        {filtered.map((c) => (
          <div
            key={c.id}
            className={`group mb-0.5 rounded-lg px-2 py-1.5 ${c.id === activeId ? "bg-accent/15" : "hover:bg-line/50"}`}
          >
            {renaming === c.id ? (
              <input
                autoFocus
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                onBlur={() => saveRename(c.id)}
                onKeyDown={(e) => e.key === "Enter" && saveRename(c.id)}
                className="w-full rounded border border-accent bg-paper px-2 py-1 text-base"
              />
            ) : (
              <>
                <button onClick={() => openConv(c.id)} className="block w-full truncate text-left text-sm font-medium">
                  {c.title}
                </button>
                <div className="mt-0.5 flex gap-1 text-mute">
                  <button
                    className={small}
                    onClick={() => {
                      setRenaming(c.id);
                      setRenameValue(c.title);
                    }}
                  >
                    {t("rename")}
                  </button>
                  <button className={small} onClick={() => removeConv(c.id)}>
                    {t("del")}
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </nav>
      <div className="space-y-1 border-t border-line p-3 text-sm">
        <p className="truncate px-1 text-mute">{email}</p>
        <div className="flex flex-wrap gap-1">
          <button className={small} onClick={toggleTheme}>{t("theme")}</button>
          <button className={small} onClick={() => setLang(lang === "es" ? "en" : "es")}>{t("language")}</button>
          <button className={small} onClick={logout}>{t("logout")}</button>
        </div>
        <button className={`${small} text-red-600 dark:text-red-400`} onClick={deleteAccount}>
          {t("deleteAccount")}
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex h-[100dvh]">
      <div className="hidden md:block">{sidebar}</div>
      {drawer && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setDrawer(false)} />
          <div className="relative h-full w-72 max-w-[85%]">{sidebar}</div>
        </div>
      )}

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-line px-3 py-2 md:hidden">
          <button onClick={() => setDrawer(true)} aria-label={t("menu")} className="rounded-md px-2 py-1 text-lg">
            ☰
          </button>
          <span className="font-extrabold tracking-tight">
            ULTRA<span className="text-accent">.</span>AI
          </span>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-3xl px-4 py-6">
            {messages.length === 0 ? (
              <div className="pt-[12vh]">
                <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">{t("emptyTitle")}</h1>
                <p className="mt-4 max-w-md text-mute">{t("emptyText")}</p>
              </div>
            ) : (
              <ul className="space-y-6">
                {messages.map((m, i) => (
                  <li key={m.id ?? i} className={m.role === "user" ? "flex justify-end" : ""}>
                    {m.role === "user" ? (
                      <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl bg-accent px-4 py-2.5 text-on-accent">
                        {m.content}
                      </div>
                    ) : (
                      <div className="w-full">
                        <div className="md">
                          <ReactMarkdown>{m.content || "…"}</ReactMarkdown>
                        </div>
                        {m.content && !(streaming && i === messages.length - 1) && (
                          <button onClick={() => copy(m.content, i)} className={`${small} mt-1 text-mute`}>
                            {copiedIdx === i ? t("copied") : t("copy")}
                          </button>
                        )}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )}
            <div ref={bottomRef} />
          </div>
        </div>

        <div className="border-t border-line bg-paper px-3 pb-3 pt-2">
          <div className="mx-auto max-w-3xl">
            {error && (
              <p role="alert" className="mb-2 rounded-lg border border-line bg-surface p-3 text-sm text-red-600 dark:text-red-400">
                {error}
              </p>
            )}
            <form onSubmit={send} className="flex items-end gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(min-width: 768px)").matches) {
                    e.preventDefault();
                    send();
                  }
                }}
                rows={1}
                maxLength={8000}
                placeholder={t("placeholder")}
                aria-label={t("placeholder")}
                className="max-h-40 min-h-[44px] flex-1 resize-none rounded-xl border border-line bg-surface px-3 py-2.5 text-base outline-none focus:border-accent"
              />
              <button
                disabled={streaming || !input.trim()}
                className="h-11 rounded-xl bg-accent px-4 font-semibold text-on-accent disabled:opacity-50"
              >
                {t("send")}
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}

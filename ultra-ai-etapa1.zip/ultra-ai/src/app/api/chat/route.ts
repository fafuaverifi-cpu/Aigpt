import Anthropic from "@anthropic-ai/sdk";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const maxDuration = 60;

const bodySchema = z.object({
  conversationId: z.string().uuid().nullable().optional(),
  message: z.string().trim().min(1).max(8000),
});

const SYSTEM_PROMPT =
  "Eres ULTRA AI, un asistente útil y claro. Responde en el idioma del usuario. " +
  "Si no sabes algo, dilo; no inventes datos.";

// Límite simple por minuto (en memoria). En serverless es solo una barrera básica;
// el límite diario por plan de abajo es el control real.
const hits = new Map<string, number[]>();
function tooFast(userId: string) {
  const now = Date.now();
  const recent = (hits.get(userId) ?? []).filter((t) => now - t < 60_000);
  recent.push(now);
  hits.set(userId, recent);
  return recent.length > 12;
}

const json = (error: string, status: number) =>
  new Response(JSON.stringify({ error }), {
    status,
    headers: { "Content-Type": "application/json" },
  });

export async function POST(req: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return json("Debes iniciar sesión.", 401);

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return json(
      "Falta ANTHROPIC_API_KEY. Añádela en .env.local (o en las variables de Vercel) y reinicia. Mira el README.",
      503
    );
  }

  let parsed;
  try {
    parsed = bodySchema.safeParse(await req.json());
  } catch {
    return json("Solicitud no válida.", 400);
  }
  if (!parsed.success) return json("Mensaje vacío o demasiado largo (máx. 8000 caracteres).", 400);
  const { message } = parsed.data;
  let conversationId = parsed.data.conversationId ?? null;

  if (tooFast(user.id)) return json("Vas muy rápido. Espera un momento.", 429);

  // Límite diario por plan (se verifica en el servidor)
  const { data: profile } = await supabase.from("profiles").select("plan").eq("id", user.id).single();
  const plan = profile?.plan ?? "free";
  if (plan === "free") {
    const limit = Number(process.env.FREE_DAILY_MESSAGE_LIMIT ?? 20);
    const start = new Date();
    start.setUTCHours(0, 0, 0, 0);
    const { count } = await supabase
      .from("messages")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user.id)
      .eq("role", "user")
      .gte("created_at", start.toISOString());
    if ((count ?? 0) >= limit) {
      return json(`Llegaste al límite diario de ${limit} mensajes del plan Gratis. Vuelve mañana.`, 429);
    }
  }

  if (conversationId) {
    const { data: conv } = await supabase.from("conversations").select("id").eq("id", conversationId).single();
    if (!conv) return json("Conversación no encontrada.", 404);
  } else {
    const { data: conv, error } = await supabase
      .from("conversations")
      .insert({ user_id: user.id, title: message.slice(0, 60) })
      .select("id")
      .single();
    if (error || !conv) return json("No se pudo crear la conversación.", 500);
    conversationId = conv.id;
  }

  const { error: insErr } = await supabase
    .from("messages")
    .insert({ conversation_id: conversationId, user_id: user.id, role: "user", content: message });
  if (insErr) return json("No se pudo guardar el mensaje.", 500);

  const { data: rows } = await supabase
    .from("messages")
    .select("role, content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: false })
    .limit(30);
  const history = (rows ?? []).reverse().map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content as string,
  }));

  const client = new Anthropic({ apiKey });
  const encoder = new TextEncoder();
  const convId = conversationId as string;

  const stream = new ReadableStream({
    async start(controller) {
      let full = "";
      try {
        const s = client.messages.stream({
          model: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-5-5",
          max_tokens: Number(process.env.ANTHROPIC_MAX_TOKENS ?? 2048),
          system: SYSTEM_PROMPT,
          messages: history,
        });
        for await (const ev of s) {
          if (ev.type === "content_block_delta" && ev.delta.type === "text_delta") {
            full += ev.delta.text;
            controller.enqueue(encoder.encode(ev.delta.text));
          }
        }
        const final = await s.finalMessage();
        await supabase.from("messages").insert({
          conversation_id: convId,
          user_id: user.id,
          role: "assistant",
          content: full,
          input_tokens: final.usage.input_tokens,
          output_tokens: final.usage.output_tokens,
        });
        await supabase
          .from("conversations")
          .update({ updated_at: new Date().toISOString() })
          .eq("id", convId);
      } catch (e) {
        console.error("Error del proveedor de IA:", e);
        controller.enqueue(
          encoder.encode("\n\n[No se pudo completar la respuesta. Revisa la clave y el modelo configurados.]")
        );
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Conversation-Id": convId,
    },
  });
}

import { createClient as createAdmin } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

export async function DELETE() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return Response.json({ error: "Debes iniciar sesión." }, { status: 401 });

  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return Response.json(
      { error: "Falta SUPABASE_SERVICE_ROLE_KEY en el servidor. Mira el README." },
      { status: 503 }
    );
  }
  const admin = createAdmin(process.env.NEXT_PUBLIC_SUPABASE_URL!, serviceKey, {
    auth: { persistSession: false },
  });
  const { error } = await admin.auth.admin.deleteUser(user.id); // borra en cascada perfil, chats y mensajes
  if (error) return Response.json({ error: "No se pudo eliminar la cuenta." }, { status: 500 });
  await supabase.auth.signOut();
  return Response.json({ ok: true });
}

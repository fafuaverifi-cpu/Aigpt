"use client";
import { useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import { Wordmark } from "@/components/AuthForm";

export default function Page() {
  const { t } = useI18n();
  const supabase = useMemo(() => createClient(), []);
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${location.origin}/auth/callback?next=/reset-password`,
    });
    setDone(true); // misma respuesta exista o no el correo
  }

  return (
    <main className="min-h-screen grid place-items-center px-5">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="mt-8 mb-5 text-xl font-semibold">{t("forgot")}</h1>
        {done ? (
          <p role="status">{t("resetSent")}</p>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <input className="w-full rounded-lg border border-line bg-surface px-3 py-2.5 text-base" type="email" required placeholder={t("email")} value={email} onChange={(e) => setEmail(e.target.value)} />
            <button className="w-full rounded-lg bg-accent text-on-accent font-semibold py-2.5">{t("sendReset")}</button>
          </form>
        )}
      </div>
    </main>
  );
}

"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import { Wordmark } from "@/components/AuthForm";

export default function Page() {
  const { t } = useI18n();
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password });
    if (error) return setError(error.message);
    router.replace("/chat");
  }

  return (
    <main className="min-h-screen grid place-items-center px-5">
      <div className="w-full max-w-sm">
        <Wordmark />
        <h1 className="mt-8 mb-5 text-xl font-semibold">{t("newPassword")}</h1>
        <form onSubmit={submit} className="space-y-3">
          <input className="w-full rounded-lg border border-line bg-surface px-3 py-2.5 text-base" type="password" required minLength={8} placeholder={t("password")} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{error}</p>}
          <button className="w-full rounded-lg bg-accent text-on-accent font-semibold py-2.5">{t("savePassword")}</button>
        </form>
      </div>
    </main>
  );
}

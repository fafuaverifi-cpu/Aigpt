"use client";
import { useEffect, useState } from "react";

const dict = {
  es: {
    newChat: "Nuevo chat",
    search: "Buscar conversaciones",
    noChats: "Todavía no tienes conversaciones.",
    noResults: "Sin resultados.",
    rename: "Renombrar",
    del: "Eliminar",
    delConfirm: "¿Eliminar esta conversación? No se puede deshacer.",
    placeholder: "Escribe tu mensaje",
    send: "Enviar",
    copy: "Copiar",
    copied: "Copiado",
    emptyTitle: "¿Qué quieres crear hoy?",
    emptyText: "Pregunta, escribe, programa o resuelve un problema. Tu historial se guarda en tu cuenta.",
    logout: "Cerrar sesión",
    theme: "Cambiar tema",
    language: "English",
    deleteAccount: "Eliminar mi cuenta",
    deleteAccountConfirm: "Se borrarán tu cuenta y todas tus conversaciones. ¿Continuar?",
    menu: "Menú",
    login: "Iniciar sesión",
    register: "Crear cuenta",
    email: "Correo electrónico",
    password: "Contraseña (mínimo 8 caracteres)",
    name: "Nombre",
    forgot: "¿Olvidaste tu contraseña?",
    noAccount: "¿No tienes cuenta?",
    haveAccount: "¿Ya tienes cuenta?",
    sendReset: "Enviar enlace",
    resetSent: "Si el correo existe, recibirás un enlace para crear una contraseña nueva.",
    newPassword: "Contraseña nueva",
    savePassword: "Guardar contraseña",
    checkEmail: "Te enviamos un correo. Ábrelo y confirma tu cuenta para entrar.",
    google: "Continuar con Google",
    configMissing: "Falta configurar Supabase. Añade NEXT_PUBLIC_SUPABASE_URL y NEXT_PUBLIC_SUPABASE_ANON_KEY en .env.local (ver README).",
    genericError: "Algo salió mal. Inténtalo de nuevo.",
    untitled: "Nueva conversación",
  },
  en: {
    newChat: "New chat",
    search: "Search conversations",
    noChats: "You have no conversations yet.",
    noResults: "No results.",
    rename: "Rename",
    del: "Delete",
    delConfirm: "Delete this conversation? This can't be undone.",
    placeholder: "Type your message",
    send: "Send",
    copy: "Copy",
    copied: "Copied",
    emptyTitle: "What do you want to create today?",
    emptyText: "Ask, write, code or solve a problem. Your history is saved to your account.",
    logout: "Sign out",
    theme: "Toggle theme",
    language: "Español",
    deleteAccount: "Delete my account",
    deleteAccountConfirm: "Your account and all your conversations will be deleted. Continue?",
    menu: "Menu",
    login: "Sign in",
    register: "Create account",
    email: "Email",
    password: "Password (at least 8 characters)",
    name: "Name",
    forgot: "Forgot your password?",
    noAccount: "No account yet?",
    haveAccount: "Already have an account?",
    sendReset: "Send link",
    resetSent: "If the email exists, you'll get a link to set a new password.",
    newPassword: "New password",
    savePassword: "Save password",
    checkEmail: "We sent you an email. Open it and confirm your account to sign in.",
    google: "Continue with Google",
    configMissing: "Supabase isn't configured. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to .env.local (see README).",
    genericError: "Something went wrong. Try again.",
    untitled: "New conversation",
  },
} as const;

export type Lang = keyof typeof dict;
export type Key = keyof (typeof dict)["es"];

export function useI18n() {
  const [lang, setLangState] = useState<Lang>("es");
  useEffect(() => {
    const s = localStorage.getItem("lang");
    if (s === "es" || s === "en") setLangState(s);
  }, []);
  const setLang = (l: Lang) => {
    localStorage.setItem("lang", l);
    document.documentElement.lang = l;
    setLangState(l);
  };
  const t = (k: Key): string => dict[lang][k];
  return { t, lang, setLang };
}
